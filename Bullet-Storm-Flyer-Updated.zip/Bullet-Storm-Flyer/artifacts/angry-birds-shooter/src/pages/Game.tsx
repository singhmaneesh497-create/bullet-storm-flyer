import { useEffect, useRef, useState, useCallback } from 'react';
import { Button } from '@/components/ui/button';

// ─── Constants ──────────────────────────────────────────────────────────────
const PLAYER_SPEED = 280;
const WAVE_DELAY = 4000;
const BULLET_REWARDS: Record<string, number> = { blue: 10, red: 20, yellow: 50 };
const MAX_PARTICLES = 55; // hard cap — keeps mobile smooth

type WeaponType = 'pistol' | 'rifle' | 'shotgun' | 'sniper';
interface WeaponDef { name: string; bulletSpeed: number; damage: number; spread: number; spreadAngle: number; radius: number; color: string; }
const WEAPONS: Record<WeaponType, WeaponDef> = {
  pistol:  { name: 'Pistol',  bulletSpeed: 550, damage: 10, spread: 1, spreadAngle: 0,    radius: 4,  color: '#ffffaa' },
  rifle:   { name: 'Rifle',   bulletSpeed: 750, damage: 18, spread: 1, spreadAngle: 0,    radius: 4,  color: '#88ffff' },
  shotgun: { name: 'Shotgun', bulletSpeed: 500, damage: 12, spread: 3, spreadAngle: 0.25, radius: 5,  color: '#ffaa44' },
  sniper:  { name: 'Sniper',  bulletSpeed: 1100,damage: 45, spread: 1, spreadAngle: 0,    radius: 3,  color: '#ff44ff' },
};
const WEAPON_ORDER: WeaponType[] = ['pistol', 'rifle', 'shotgun', 'sniper'];

// ─── Mission Config ──────────────────────────────────────────────────────────
interface MissionConfig { blue: number; red: number; yellow: number; isBoss: boolean; startBullets: number; }
function getMissionConfig(mission: number): MissionConfig {
  const isBoss = mission % 10 === 0;
  const speedScale = Math.floor((mission - 1) / 3);
  const startBullets = Math.max(30, 50 - speedScale * 3);
  if (isBoss) return { blue: 10, red: 5, yellow: 1, isBoss: true, startBullets };
  switch (mission) {
    case 1: return { blue: 10, red: 2,  yellow: 0, isBoss: false, startBullets: 50 };
    case 2: return { blue: 15, red: 4,  yellow: 0, isBoss: false, startBullets: 48 };
    case 3: return { blue: 20, red: 6,  yellow: 0, isBoss: false, startBullets: 46 };
    case 4: return { blue: 25, red: 8,  yellow: 1, isBoss: false, startBullets: 44 };
    case 5: return { blue: 30, red: 10, yellow: 1, isBoss: false, startBullets: 42 };
    case 6: return { blue: 35, red: 12, yellow: 2, isBoss: false, startBullets: 40 };
    default: { const extra = mission - 6; return { blue: 35 + extra * 5, red: 12 + extra * 2, yellow: 2 + Math.floor(extra / 2), isBoss: false, startBullets }; }
  }
}

// One new sky scene after every two completed missions (1–2, 3–4, 5–6, then repeat).
function getBackgroundIndex(mission: number): number {
  return Math.floor((mission - 1) / 2) % 3;
}

// ─── Types ───────────────────────────────────────────────────────────────────
interface Vector2 { x: number; y: number; }
interface Cloud { x: number; y: number; w: number; h: number; speed: number; alpha: number; depth: number; sprite: HTMLCanvasElement; }
interface Particle {
  x: number; y: number; vx: number; vy: number;
  life: number; maxLife: number;
  color: string; size: number;
  type: 'spark' | 'smoke' | 'feather' | 'floatText';
  text?: string;
  rotation?: number;
  rotSpeed?: number;
  gravity?: number;
}
interface Projectile { x: number; y: number; vx: number; vy: number; radius: number; damage: number; isEnemy: boolean; color?: string; trail?: Vector2[]; }
interface Enemy {
  id: string; type: 'blue' | 'red' | 'yellow' | 'boss';
  x: number; y: number; width: number; height: number;
  hp: number; maxHp: number; vx: number; vy: number; baseSpeed: number;
  lastAttackTime: number; lastShootTime: number;
  state: 'entering' | 'attacking' | 'retreating' | 'dead';
  targetY: number; auraPhase: number; zigzagPhase: number;
  dirChangeTimer: number; boostTimer: number; boostCooldown: number;
}
interface HudData { hp: number; maxHp: number; bullets: number; mission: number; score: number; combo: number; weapon: WeaponType; damageBoosted: boolean; weaponUnlocked: string; shieldCharges: number; shieldActive: boolean; shieldTimer: number; }
interface GameStateRef {
  isGameOver: boolean;
  player: { x: number; y: number; width: number; height: number; hp: number; maxHp: number; damage: number; bullets: number; hitFlashTime: number; };
  enemies: Enemy[]; spawnQueue: Array<'blue' | 'red' | 'yellow' | 'boss'>; spawnTimer: number; spawnInterval: number;
  projectiles: Projectile[]; particles: Particle[]; clouds: Cloud[];
  mission: number; score: number; lastTime: number;
  missionState: 'active' | 'cleared'; missionTimer: number;
  keys: Record<string, boolean>; joystick: { active: boolean; dx: number; dy: number };
  screenShake: number; bgOffset: number;
  backgroundIndex: number; previousBackgroundIndex: number; backgroundTransition: number;
  images: Record<string, HTMLImageElement>; imagesLoaded: boolean;
  bgImages: HTMLImageElement[]; bgImagesLoaded: number;
  combo: number; comboTimer: number; damageBoostedTime: number;
  shieldCharges: number; shieldActive: boolean; shieldTimer: number;
  currentWeapon: WeaponType; unlockedWeapons: Set<WeaponType>;
  notification: string; notificationTimer: number; speedScale: number;
  lastShotTime: number;
}

// ─── Audio Engine ────────────────────────────────────────────────────────────
let audioCtx: AudioContext | null = null;
function getAudio(): AudioContext | null {
  if (!audioCtx) { try { audioCtx = new AudioContext(); } catch { return null; } }
  return audioCtx;
}

// ── Background Music ──────────────────────────────────────────────────────────
let bgMusicInterval: ReturnType<typeof setInterval> | null = null;
let bgMusicMasterGain: GainNode | null = null;
let bgMusicBeat = 0;

function startBGMusic() {
  const ac = getAudio(); if (!ac) return;
  ac.resume();
  if (bgMusicInterval) return; // already playing

  bgMusicMasterGain = ac.createGain();
  bgMusicMasterGain.gain.setValueAtTime(0.07, ac.currentTime);
  bgMusicMasterGain.connect(ac.destination);

  // Epic A-minor scale melody + bass pattern
  const melody  = [220, 261, 294, 330, 294, 247, 220, 196, 220, 294, 330, 392, 440, 392, 330, 294];
  const harmony = [165, 196, 220, 261, 220, 196, 165, 147, 165, 220, 261, 330, 349, 330, 294, 247];
  const bass    = [110, 110, 131, 131, 165, 165, 147, 147, 110, 110, 131, 131, 165, 165, 147, 147];
  const bps = 0.22; // seconds per beat (≈ 116 BPM epic pace)

  const tick = () => {
    const ac2 = getAudio(); if (!ac2 || !bgMusicMasterGain) return;
    const now = ac2.currentTime;
    const i = bgMusicBeat % melody.length;

    // Melody — triangle for warm tone
    const m = ac2.createOscillator(); const mg = ac2.createGain();
    m.type = 'triangle'; m.frequency.setValueAtTime(melody[i], now);
    mg.gain.setValueAtTime(0, now);
    mg.gain.linearRampToValueAtTime(0.5, now + 0.015);
    mg.gain.exponentialRampToValueAtTime(0.001, now + bps * 0.88);
    m.connect(mg); mg.connect(bgMusicMasterGain); m.start(now); m.stop(now + bps);

    // Harmony — every 2 beats, lower sine
    if (bgMusicBeat % 2 === 0) {
      const h = ac2.createOscillator(); const hg = ac2.createGain();
      h.type = 'sine'; h.frequency.setValueAtTime(harmony[i], now);
      hg.gain.setValueAtTime(0, now);
      hg.gain.linearRampToValueAtTime(0.28, now + 0.02);
      hg.gain.exponentialRampToValueAtTime(0.001, now + bps * 1.7);
      h.connect(hg); hg.connect(bgMusicMasterGain); h.start(now); h.stop(now + bps * 2);
    }

    // Bass — every 2 beats, sawtooth with filter
    if (bgMusicBeat % 2 === 0) {
      const b = ac2.createOscillator(); const bg = ac2.createGain();
      const filt = ac2.createBiquadFilter(); filt.type = 'lowpass'; filt.frequency.setValueAtTime(300, now);
      b.type = 'sawtooth'; b.frequency.setValueAtTime(bass[i], now);
      bg.gain.setValueAtTime(0, now);
      bg.gain.linearRampToValueAtTime(0.4, now + 0.01);
      bg.gain.exponentialRampToValueAtTime(0.001, now + bps * 1.9);
      b.connect(filt); filt.connect(bg); bg.connect(bgMusicMasterGain); b.start(now); b.stop(now + bps * 2);
    }

    // Occasional drum kick on beat 1 and 9
    if (i === 0 || i === 8) {
      const k = ac2.createOscillator(); const kg = ac2.createGain();
      k.type = 'sine'; k.frequency.setValueAtTime(160, now); k.frequency.exponentialRampToValueAtTime(40, now + 0.06);
      kg.gain.setValueAtTime(0.5, now); kg.gain.exponentialRampToValueAtTime(0.001, now + 0.08);
      k.connect(kg); kg.connect(bgMusicMasterGain); k.start(now); k.stop(now + 0.08);
    }

    bgMusicBeat++;
  };

  tick();
  bgMusicInterval = setInterval(tick, bps * 1000);
}

function stopBGMusic() {
  if (bgMusicInterval) { clearInterval(bgMusicInterval); bgMusicInterval = null; }
  bgMusicBeat = 0;
  if (bgMusicMasterGain) {
    try { bgMusicMasterGain.gain.setValueAtTime(0.001, (getAudio()?.currentTime || 0) + 0.3); } catch { /**/ }
    bgMusicMasterGain = null;
  }
}

function playShoot(weapon: WeaponType) {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  const buf = ctx.createBuffer(1, ctx.sampleRate * 0.08, ctx.sampleRate);
  const data = buf.getChannelData(0);
  for (let i = 0; i < data.length; i++) {
    const t = i / ctx.sampleRate;
    const freq = weapon === 'sniper' ? 120 : weapon === 'shotgun' ? 200 : weapon === 'rifle' ? 180 : 250;
    data[i] = (Math.random() * 2 - 1) * Math.exp(-t * (weapon === 'sniper' ? 20 : 40)) * Math.sin(freq * t * Math.PI * 2) * 0.6;
  }
  const src = ctx.createBufferSource(); src.buffer = buf;
  const gain = ctx.createGain(); gain.gain.setValueAtTime(weapon === 'sniper' ? 0.5 : 0.3, ctx.currentTime);
  src.connect(gain); gain.connect(ctx.destination); src.start();
}
function playHit() {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  const osc = ctx.createOscillator(); const gain = ctx.createGain();
  osc.type = 'square'; osc.frequency.setValueAtTime(220, ctx.currentTime); osc.frequency.exponentialRampToValueAtTime(80, ctx.currentTime + 0.08);
  gain.gain.setValueAtTime(0.15, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.1);
  osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + 0.1);
}
function playKill() {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  [0, 0.06, 0.12].forEach((delay, i) => {
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(440 + i * 180, ctx.currentTime + delay);
    gain.gain.setValueAtTime(0.2, ctx.currentTime + delay); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + delay + 0.15);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(ctx.currentTime + delay); osc.stop(ctx.currentTime + delay + 0.15);
  });
}
function playGameOver() {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  [440, 330, 220, 165].forEach((freq, i) => {
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sawtooth'; osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.2);
    gain.gain.setValueAtTime(0.2, ctx.currentTime + i * 0.2); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.2 + 0.25);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(ctx.currentTime + i * 0.2); osc.stop(ctx.currentTime + i * 0.2 + 0.25);
  });
}
function playMissionClear() {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  [523, 659, 784, 1047].forEach((freq, i) => {
    const osc = ctx.createOscillator(); const gain = ctx.createGain();
    osc.type = 'sine'; osc.frequency.setValueAtTime(freq, ctx.currentTime + i * 0.12);
    gain.gain.setValueAtTime(0.25, ctx.currentTime + i * 0.12); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + i * 0.12 + 0.2);
    osc.connect(gain); gain.connect(ctx.destination); osc.start(ctx.currentTime + i * 0.12); osc.stop(ctx.currentTime + i * 0.12 + 0.2);
  });
}
function playPlayerHit() {
  const ctx = getAudio(); if (!ctx) return;
  ctx.resume();
  const osc = ctx.createOscillator(); const gain = ctx.createGain();
  osc.type = 'sawtooth'; osc.frequency.setValueAtTime(180, ctx.currentTime); osc.frequency.exponentialRampToValueAtTime(60, ctx.currentTime + 0.18);
  gain.gain.setValueAtTime(0.3, ctx.currentTime); gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + 0.2);
  osc.connect(gain); gain.connect(ctx.destination); osc.start(); osc.stop(ctx.currentTime + 0.2);
}

// ─── Cached volumetric cloud sprites ────────────────────────────────────────
// Create the gradients once per cloud, then draw cached canvases every frame.
// This keeps the richer cloud look smooth on mid-range Android phones.
function createCloudSprite(depth: number): HTMLCanvasElement {
  const canvas = document.createElement('canvas');
  canvas.width = 320;
  canvas.height = 176;
  const ctx = canvas.getContext('2d');
  if (!ctx) return canvas;

  // Soft atmospheric shadow beneath the cloud mass.
  const shadow = ctx.createRadialGradient(160, 132, 12, 160, 132, 142);
  shadow.addColorStop(0, `rgba(25,48,78,${0.22 + depth * 0.12})`);
  shadow.addColorStop(1, 'rgba(25,48,78,0)');
  ctx.fillStyle = shadow;
  ctx.fillRect(0, 40, 320, 136);

  // Layered cloud lobes create a fuller cumuliform silhouette.
  const lobes = [
    { x: 54, y: 91, rx: 53, ry: 35 },
    { x: 103, y: 67, rx: 61, ry: 52 },
    { x: 164, y: 55, rx: 67, ry: 58 },
    { x: 225, y: 78, rx: 59, ry: 46 },
    { x: 273, y: 98, rx: 38, ry: 29 },
    { x: 145, y: 105, rx: 120, ry: 35 },
  ];
  for (const lobe of lobes) {
    const puff = ctx.createRadialGradient(
      lobe.x - lobe.rx * 0.24, lobe.y - lobe.ry * 0.42, 2,
      lobe.x, lobe.y, Math.max(lobe.rx, lobe.ry) * 1.12,
    );
    puff.addColorStop(0, '#ffffff');
    puff.addColorStop(0.34, '#f7fbff');
    puff.addColorStop(0.68, '#dce9f5');
    puff.addColorStop(1, '#8fa8c2');
    ctx.beginPath();
    ctx.ellipse(lobe.x, lobe.y, lobe.rx, lobe.ry, 0, 0, Math.PI * 2);
    ctx.fillStyle = puff;
    ctx.fill();
  }

  // Cool underside shading gives the cloud depth against bright skies.
  const underside = ctx.createLinearGradient(0, 86, 0, 158);
  underside.addColorStop(0, 'rgba(102,132,164,0)');
  underside.addColorStop(0.55, `rgba(91,119,151,${0.16 + depth * 0.10})`);
  underside.addColorStop(1, `rgba(48,70,100,${0.28 + depth * 0.12})`);
  ctx.fillStyle = underside;
  ctx.beginPath();
  ctx.ellipse(160, 111, 145, 43, 0, 0, Math.PI * 2);
  ctx.fill();

  // Thin sunlit rims and soft highlights on the upper lobes.
  ctx.save();
  ctx.globalCompositeOperation = 'screen';
  const rim = ctx.createRadialGradient(132, 38, 4, 145, 52, 125);
  rim.addColorStop(0, 'rgba(255,255,255,0.72)');
  rim.addColorStop(0.48, 'rgba(255,255,255,0.20)');
  rim.addColorStop(1, 'rgba(255,255,255,0)');
  ctx.fillStyle = rim;
  ctx.beginPath();
  ctx.ellipse(153, 58, 126, 48, -0.08, 0, Math.PI * 2);
  ctx.fill();
  ctx.restore();
  return canvas;
}

function drawClouds(ctx: CanvasRenderingContext2D, clouds: Cloud[]) {
  for (const cloud of clouds) {
    ctx.save();
    ctx.globalAlpha = cloud.alpha;
    ctx.drawImage(cloud.sprite, cloud.x, cloud.y - cloud.h / 2, cloud.w, cloud.h);
    ctx.restore();
  }
}

// ─── Component ───────────────────────────────────────────────────────────────
export default function Game() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const [gamePhase, setGamePhase] = useState<'start' | 'playing' | 'gameover'>('start');
  const [musicEnabled, setMusicEnabled] = useState(false);
  const musicEnabledRef = useRef(false);
  const [hudData, setHudData] = useState<HudData>({ hp: 100, maxHp: 100, bullets: 50, mission: 1, score: 0, combo: 0, weapon: 'pistol', damageBoosted: false, weaponUnlocked: '' });
  const requestRef = useRef<number | null>(null);
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const joystickStickRef = useRef<HTMLDivElement>(null);
  const gamePhaseRef = useRef<'start' | 'playing' | 'gameover'>('start');
  const missionClearPlayed = useRef(false);
  const toggleMusic = useCallback(() => {
    const enabled = !musicEnabledRef.current;
    musicEnabledRef.current = enabled;
    setMusicEnabled(enabled);
    if (enabled) startBGMusic(); else stopBGMusic();
  }, []);
  // Cached canvas 2d context — avoids getContext() every frame
  const ctxRef = useRef<CanvasRenderingContext2D | null>(null);

  const makeClouds = (w: number, h: number): Cloud[] =>
    Array.from({ length: 13 }, () => {
      const depth = 0.25 + Math.random() * 0.75;
      return {
        x: Math.random() * (w + 180) - 90,
        y: h * 0.04 + Math.random() * h * 0.58,
        w: 115 + Math.random() * 175,
        h: 42 + Math.random() * 52,
        speed: 20 + depth * 42,
        alpha: 0.26 + depth * 0.28,
        depth,
        sprite: createCloudSprite(depth),
      };
    }).sort((a, b) => a.depth - b.depth);

  const state = useRef<GameStateRef>({
    isGameOver: false,
    player: { x: 100, y: 300, width: 70, height: 70, hp: 100, maxHp: 100, damage: 10, bullets: 50, hitFlashTime: 0 },
    enemies: [], spawnQueue: [], spawnTimer: 0, spawnInterval: 1.5,
    projectiles: [], particles: [], clouds: [],
    mission: 1, score: 0, lastTime: 0,
    missionState: 'active', missionTimer: 0,
    keys: {}, joystick: { active: false, dx: 0, dy: 0 },
    screenShake: 0, bgOffset: 0,
    backgroundIndex: 0, previousBackgroundIndex: 0, backgroundTransition: 0,
    images: {}, imagesLoaded: false,
    bgImages: [], bgImagesLoaded: 0,
    combo: 0, comboTimer: 0, damageBoostedTime: 0,
    shieldCharges: 0, shieldActive: false, shieldTimer: 0,
    currentWeapon: 'pistol', unlockedWeapons: new Set(['pistol']),
    notification: '', notificationTimer: 0, speedScale: 0,
    lastShotTime: 0,
  });

  // Load sprite images
  useEffect(() => {
    const urls: Record<string, string> = {
      player: `${import.meta.env.BASE_URL}hero-plane.png`, blueBird: `${import.meta.env.BASE_URL}blue-bird.png`, redBird: `${import.meta.env.BASE_URL}red-bird.png`, yellowBird: `${import.meta.env.BASE_URL}yellow-bird.png`,
    };
    let loaded = 0; const total = Object.keys(urls).length;
    for (const [key, url] of Object.entries(urls)) {
      const img = new Image(); img.src = url;
      img.onload = () => { state.current.images[key] = img; if (++loaded === total) state.current.imagesLoaded = true; };
      img.onerror = () => { if (++loaded === total) state.current.imagesLoaded = true; };
    }
  }, []);

  // Load background images (bg-1, bg-2, bg-3)
  useEffect(() => {
    const bgUrls = [`${import.meta.env.BASE_URL}bg-1.png`, `${import.meta.env.BASE_URL}bg-2.png`, `${import.meta.env.BASE_URL}bg-3.png`];
    const s = state.current;
    s.bgImages = [];
    bgUrls.forEach((url, i) => {
      const img = new Image(); img.src = url;
      img.onload = () => { s.bgImages[i] = img; s.bgImagesLoaded++; };
      img.onerror = () => { s.bgImagesLoaded++; }; // silently skip missing
    });
  }, []);

  // Keyboard
  useEffect(() => {
    const onDown = (e: KeyboardEvent) => { state.current.keys[e.code] = true; if (e.code === 'Space') e.preventDefault(); };
    const onUp = (e: KeyboardEvent) => {
      state.current.keys[e.code] = false;
      if (e.code === 'Space' && gamePhaseRef.current === 'playing') fireBullet();
      if (e.code === 'KeyQ' && gamePhaseRef.current === 'playing') cycleWeapon(-1);
      if (e.code === 'KeyE' && gamePhaseRef.current === 'playing') cycleWeapon(1);
    };
    window.addEventListener('keydown', onDown); window.addEventListener('keyup', onUp);
    return () => { window.removeEventListener('keydown', onDown); window.removeEventListener('keyup', onUp); };
  }, []);

  const cycleWeapon = useCallback((dir: number) => {
    const s = state.current;
    const available = WEAPON_ORDER.filter(w => s.unlockedWeapons.has(w));
    if (available.length <= 1) return;
    const idx = available.indexOf(s.currentWeapon);
    s.currentWeapon = available[(idx + dir + available.length) % available.length];
    syncHud();
  }, []);

  const fireBullet = useCallback(() => {
    const s = state.current;
    const weapon = WEAPONS[s.currentWeapon];
    if (s.player.bullets <= 0 || s.isGameOver) return;
    const now = performance.now();
    if (now - s.lastShotTime < 120) return;
    s.lastShotTime = now;
    const dmg = s.damageBoostedTime > 0 ? weapon.damage * 2 : weapon.damage + (s.player.damage - 10);
    const baseVx = weapon.bulletSpeed;
    for (let i = 0; i < weapon.spread; i++) {
      const angle = (i - (weapon.spread - 1) / 2) * weapon.spreadAngle;
      s.projectiles.push({ x: s.player.x + s.player.width, y: s.player.y + s.player.height / 2, vx: baseVx * Math.cos(angle), vy: baseVx * Math.sin(angle), radius: weapon.radius, damage: dmg, isEnemy: false, color: weapon.color, trail: [] });
    }
    s.player.bullets--;
    s.screenShake = Math.max(s.screenShake, 1.2);
    playShoot(s.currentWeapon);
    syncHud();
  }, []);

  const syncHud = () => {
    const s = state.current;
    setHudData({ hp: Math.max(0, s.player.hp), maxHp: s.player.maxHp, bullets: s.player.bullets, mission: s.mission, score: s.score, combo: s.combo, weapon: s.currentWeapon, damageBoosted: s.damageBoostedTime > 0, weaponUnlocked: s.notification, shieldCharges: s.shieldCharges, shieldActive: s.shieldActive, shieldTimer: Math.ceil(s.shieldTimer) });
  };

  const activateShield = useCallback(() => {
    const s = state.current;
    if (s.shieldActive || s.shieldCharges <= 0 || s.isGameOver) return;
    s.shieldCharges--;
    s.shieldActive = true;
    s.shieldTimer = 7;
    showNotification('🛡️ SHIELD ACTIVATED! 7s invincible!');
    // Play shield activate sound
    const ac = getAudio(); if (ac) { ac.resume(); const o = ac.createOscillator(); const g = ac.createGain(); o.type = 'sine'; o.frequency.setValueAtTime(440, ac.currentTime); o.frequency.linearRampToValueAtTime(880, ac.currentTime + 0.3); g.gain.setValueAtTime(0.25, ac.currentTime); g.gain.exponentialRampToValueAtTime(0.001, ac.currentTime + 0.4); o.connect(g); g.connect(ac.destination); o.start(); o.stop(ac.currentTime + 0.4); }
    syncHud();
  }, []);

  const showNotification = (msg: string) => { const s = state.current; s.notification = msg; s.notificationTimer = 3; syncHud(); };

  // ── Particle factories (capped at MAX_PARTICLES) ───────────────────────────
  const createSparks = (x: number, y: number, color: string, count = 12) => {
    const s = state.current;
    const room = MAX_PARTICLES - s.particles.length;
    const n = Math.min(count, room);
    for (let i = 0; i < n; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = 50 + Math.random() * 180;
      s.particles.push({ x, y, vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd, life: 0.5 + Math.random() * 0.4, maxLife: 0.5 + Math.random() * 0.4, color: Math.random() > 0.4 ? color : '#ffffff', size: 2 + Math.random() * 4, type: 'spark', gravity: 120 });
    }
  };

  const createSmokeBurst = (x: number, y: number, count = 8) => {
    const s = state.current;
    const room = MAX_PARTICLES - s.particles.length;
    const n = Math.min(count, room);
    for (let i = 0; i < n; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = 20 + Math.random() * 80;
      s.particles.push({ x, y, vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd - 30, life: 0.8 + Math.random() * 0.8, maxLife: 0.8 + Math.random() * 0.8, color: `hsl(0,0%,${55 + Math.random() * 25}%)`, size: 8 + Math.random() * 18, type: 'smoke', gravity: -15 });
    }
  };

  const createFeatherBurst = (x: number, y: number, birdType: string, count = 8) => {
    const s = state.current;
    const room = MAX_PARTICLES - s.particles.length;
    const n = Math.min(count, room);
    const colors: Record<string, string[]> = { blue: ['#4499ff', '#2277dd', '#88bbff'], red: ['#ff3333', '#cc1111', '#ff7755'], yellow: ['#ffcc00', '#ffaa00', '#ffe066'] };
    const palette = colors[birdType] || colors.blue;
    for (let i = 0; i < n; i++) {
      const angle = Math.random() * Math.PI * 2;
      const spd = 60 + Math.random() * 140;
      s.particles.push({ x, y, vx: Math.cos(angle) * spd, vy: Math.sin(angle) * spd - 40, life: 1.0 + Math.random() * 0.6, maxLife: 1.0 + Math.random() * 0.6, color: palette[Math.floor(Math.random() * palette.length)], size: 5 + Math.random() * 9, type: 'feather', rotation: Math.random() * Math.PI * 2, rotSpeed: (Math.random() - 0.5) * 6, gravity: 80 });
    }
  };

  const createFloatText = (x: number, y: number, text: string, color: string) => {
    if (state.current.particles.length >= MAX_PARTICLES) return;
    state.current.particles.push({ x, y, vx: (Math.random() - 0.5) * 20, vy: -60, life: 1.2, maxLife: 1.2, color, size: 14, type: 'floatText', text });
  };

  const createExplosion = (x: number, y: number, color: string, birdType?: string) => {
    createSparks(x, y, color, 10);
    createSmokeBurst(x, y, 6);
    if (birdType) createFeatherBurst(x, y, birdType, 8);
  };

  // ── Spawn + Kill ──────────────────────────────────────────────────────────
  const buildSpawnQueue = (mission: number) => {
    const cfg = getMissionConfig(mission);
    const blues: Array<'blue'> = Array(cfg.blue).fill('blue');
    const reds: Array<'red'> = Array(cfg.red).fill('red');
    const yellows: Array<'yellow'> = Array(cfg.yellow).fill('yellow');
    const bosses: Array<'boss'> = cfg.isBoss ? ['boss'] : [];
    return [...[...blues, ...reds].sort(() => Math.random() - 0.5), ...yellows, ...bosses];
  };

  const spawnEnemy = (type: 'blue' | 'red' | 'yellow' | 'boss') => {
    const s = state.current; const canvas = canvasRef.current; if (!canvas) return;
    const scale = s.speedScale;
    const isYellow = type === 'yellow' || type === 'boss';
    const width = isYellow ? 130 : 65; const height = isYellow ? 130 : 65;
    const hp = type === 'blue' ? 30 : type === 'red' ? 65 : type === 'yellow' ? 350 : 600;
    const realHp = hp + scale * 10;
    const baseSpeed = type === 'blue' ? 90 + scale * 12 : type === 'red' ? 140 + scale * 15 : 200 + scale * 10;
    const targetY = canvas.height * 0.12 + Math.random() * canvas.height * 0.72;
    s.enemies.push({
      id: Math.random().toString(36).substr(2, 9),
      type: type === 'boss' ? 'yellow' : type,
      x: canvas.width + 80 + Math.random() * 150, y: targetY,
      width, height, hp: realHp, maxHp: realHp,
      vx: -baseSpeed, vy: 0, baseSpeed,
      lastAttackTime: performance.now(), lastShootTime: performance.now() - 1000,
      state: 'entering', targetY, auraPhase: 0,
      zigzagPhase: Math.random() * Math.PI * 2, dirChangeTimer: 0, boostTimer: 0, boostCooldown: 4 + Math.random() * 3,
    });
  };

  const handleKill = (e: Enemy) => {
    const s = state.current;
    const reward = BULLET_REWARDS[e.type] || 10;
    s.player.bullets += reward;
    const pts = e.type === 'yellow' ? 500 : e.type === 'red' ? 100 : 50;
    s.score += pts;
    s.combo++; s.comboTimer = 4;
    createFloatText(e.x + e.width / 2, e.y, `+${pts} pts`, e.type === 'yellow' ? '#ffcc00' : e.type === 'red' ? '#ff5555' : '#55aaff');
    createFloatText(e.x + e.width / 2, e.y + 22, `+${reward} 🔫`, '#ffffff');
    // Award shield charge every 3 combo kills
    if (s.combo > 0 && s.combo % 3 === 0 && s.shieldCharges < 3) {
      s.shieldCharges++;
      showNotification(`🛡️ Shield Charge +1! (${s.shieldCharges}/3)`);
    }
    if (s.combo === 5) { s.player.bullets += 25; showNotification('5x COMBO! +25 Bonus Bullets!'); }
    else if (s.combo === 10) { s.damageBoostedTime = 8; showNotification('10x COMBO! Damage x2 for 8s!'); }
    else if (s.combo > 0 && s.combo % 10 === 0) { s.damageBoostedTime = 8; showNotification(`${s.combo}x COMBO! Damage Boost!`); }
    playKill();
    syncHud();
  };

  // ── Update ────────────────────────────────────────────────────────────────
  const update = (dt: number, time: number) => {
    const s = state.current; if (s.isGameOver) return;
    const canvas = canvasRef.current; if (!canvas) return;

    s.bgOffset += 72 * dt;
    if (s.backgroundTransition > 0) s.backgroundTransition = Math.max(0, s.backgroundTransition - dt);
    if (s.screenShake > 0) s.screenShake = Math.max(0, s.screenShake - dt * 16);

    for (const c of s.clouds) {
      c.x -= c.speed * dt;
      if (c.x + c.w + 40 < 0) {
        c.x = canvas.width + 30 + Math.random() * 140;
        c.y = canvas.height * 0.04 + Math.random() * canvas.height * 0.58;
        c.w = 115 + Math.random() * 175;
        c.h = 42 + Math.random() * 52;
        c.sprite = createCloudSprite(c.depth);
      }
    }

    if (s.comboTimer > 0) { s.comboTimer -= dt; if (s.comboTimer <= 0) { s.combo = 0; syncHud(); } }
    if (s.damageBoostedTime > 0) { s.damageBoostedTime -= dt; if (s.damageBoostedTime <= 0) syncHud(); }
    if (s.notificationTimer > 0) { s.notificationTimer -= dt; if (s.notificationTimer <= 0) { s.notification = ''; syncHud(); } }
    if (s.shieldActive) {
      s.shieldTimer -= dt;
      if (s.shieldTimer <= 0) { s.shieldActive = false; s.shieldTimer = 0; showNotification('🛡️ Shield expired!'); syncHud(); }
      else if (Math.ceil(s.shieldTimer) !== Math.ceil(s.shieldTimer + dt)) syncHud(); // tick every second
    }

    // Player movement
    let dx = 0; let dy = 0;
    if (s.keys['ArrowUp'] || s.keys['KeyW']) dy -= 1;
    if (s.keys['ArrowDown'] || s.keys['KeyS']) dy += 1;
    if (s.keys['ArrowLeft'] || s.keys['KeyA']) dx -= 1;
    if (s.keys['ArrowRight'] || s.keys['KeyD']) dx += 1;
    if (s.joystick.active) { dx = s.joystick.dx; dy = s.joystick.dy; }
    const len = Math.sqrt(dx * dx + dy * dy);
    if (len > 1 && !s.joystick.active) { dx /= len; dy /= len; }
    s.player.x = Math.max(0, Math.min(s.player.x + dx * PLAYER_SPEED * dt, canvas.width - s.player.width));
    s.player.y = Math.max(0, Math.min(s.player.y + dy * PLAYER_SPEED * dt, canvas.height - s.player.height - 10));
    if (s.player.hitFlashTime > 0) s.player.hitFlashTime -= dt;

    // Spawn
    if (s.missionState === 'active' && s.spawnQueue.length > 0) {
      s.spawnTimer -= dt;
      const activeCount = s.enemies.filter(e => e.state !== 'dead').length;
      if (s.spawnTimer <= 0 && activeCount < 8) { const next = s.spawnQueue.shift()!; spawnEnemy(next); s.spawnTimer = s.spawnInterval; }
    }

    // Projectiles
    for (let i = s.projectiles.length - 1; i >= 0; i--) {
      const p = s.projectiles[i];
      p.x += p.vx * dt; p.y += p.vy * dt;
      if (p.trail) { p.trail.push({ x: p.x, y: p.y }); if (p.trail.length > 6) p.trail.shift(); }
      if (p.isEnemy) {
        if (p.x > s.player.x && p.x < s.player.x + s.player.width && p.y > s.player.y && p.y < s.player.y + s.player.height) {
          if (s.shieldActive) {
            // Shield blocks the hit — just sparks, no damage
            createSparks(p.x, p.y, '#00ccff', 8);
            s.projectiles.splice(i, 1);
            continue;
          }
          s.player.hp -= p.damage; s.player.hitFlashTime = 0.25; s.screenShake = 7;
          s.combo = 0; s.comboTimer = 0;
          createSparks(p.x, p.y, '#ff4400', 6);
          createSmokeBurst(p.x, p.y, 3);
          playPlayerHit();
          s.projectiles.splice(i, 1); syncHud();
          if (s.player.hp <= 0) { s.isGameOver = true; playGameOver(); setGamePhase('gameover'); }
          continue;
        }
      } else {
        let hit = false;
        for (const e of s.enemies) {
          if (e.state === 'dead' || e.state === 'retreating') continue;
          if (p.x > e.x && p.x < e.x + e.width && p.y > e.y && p.y < e.y + e.height) {
            e.hp -= p.damage;
            createSparks(p.x, p.y, '#ffaa00', 5);
            playHit();
            hit = true; s.score += 10;
            if (e.hp <= 0) {
              const cx = e.x + e.width / 2; const cy = e.y + e.height / 2;
              createExplosion(cx, cy, e.type === 'red' ? '#ff3300' : e.type === 'yellow' ? '#ffcc00' : '#33aaff', e.type);
              if (e.type === 'yellow') { e.state = 'retreating'; e.vx = 250; handleKill(e); }
              else { e.state = 'dead'; handleKill(e); }
            }
            break;
          }
        }
        if (hit) { s.projectiles.splice(i, 1); continue; }
      }
      if (p.x < -120 || p.x > canvas.width + 120 || p.y < -120 || p.y > canvas.height + 120) s.projectiles.splice(i, 1);
    }

    // Enemies
    let allCleared = s.spawnQueue.length === 0;
    for (let i = s.enemies.length - 1; i >= 0; i--) {
      const e = s.enemies[i];
      if (e.state === 'dead') { s.enemies.splice(i, 1); continue; }
      if (e.type !== 'yellow' && e.state !== 'retreating') allCleared = false;

      if (e.state === 'entering') {
        e.x += e.vx * dt;
        if (e.x < canvas.width - e.width - 80) { e.state = 'attacking'; e.vx = 0; }
      } else if (e.state === 'attacking') {
        e.auraPhase += dt * 4;

        if (e.type === 'blue') {
          // Track player vertically
          const targetVy = (s.player.y - e.y) * 0.8;
          e.vy += (targetVy - e.vy) * dt * 2;
          e.vy = Math.max(-e.baseSpeed * 0.6, Math.min(e.baseSpeed * 0.6, e.vy));
          e.vx = -e.baseSpeed * 0.4;
          e.x += e.vx * dt; e.y += e.vy * dt;
          // Clamp to screen
          if (e.y < 20) e.vy = Math.abs(e.vy);
          if (e.y > canvas.height - e.height - 20) e.vy = -Math.abs(e.vy);

          // Beak melee attack when very close
          if (time - e.lastAttackTime > 900) {
            const px = s.player.x + s.player.width / 2; const py = s.player.y + s.player.height / 2;
            const ex = e.x + e.width / 2; const ey = e.y + e.height / 2;
            if (Math.abs(px - ex) < 55 && Math.abs(py - ey) < 55) {
              e.lastAttackTime = time;
              if (s.shieldActive) { createSparks(px, py, '#00ccff', 6); }
              else {
                s.player.hp -= 8; s.player.hitFlashTime = 0.2; s.screenShake = 4;
                s.combo = 0; s.comboTimer = 0; syncHud(); playPlayerHit();
                if (s.player.hp <= 0) { s.isGameOver = true; playGameOver(); setGamePhase('gameover'); }
              }
            }
          }
          // ★ NEW: Blue bird also shoots feather projectiles like red bird ★
          if (time - e.lastShootTime > 2400) {
            const dirX = s.player.x + s.player.width / 2 - (e.x + e.width / 2);
            const dirY = s.player.y + s.player.height / 2 - (e.y + e.height / 2);
            const dlen = Math.sqrt(dirX * dirX + dirY * dirY) || 1;
            s.projectiles.push({ x: e.x, y: e.y + e.height / 2, vx: (dirX / dlen) * 290, vy: (dirY / dlen) * 290, radius: 6, damage: 8, isEnemy: true, color: '#44aaff', trail: [] });
            e.lastShootTime = time;
          }

        } else if (e.type === 'red') {
          e.dirChangeTimer -= dt;
          if (e.dirChangeTimer <= 0) { e.vy = (Math.random() - 0.5) * e.baseSpeed * 1.6; e.vx = (Math.random() - 0.5) * e.baseSpeed * 0.5 - e.baseSpeed * 0.3; e.dirChangeTimer = 1.2 + Math.random() * 1.5; }
          e.x += e.vx * dt; e.y += e.vy * dt;
          if (e.y < 20) e.vy = Math.abs(e.vy);
          if (e.y > canvas.height - e.height - 20) e.vy = -Math.abs(e.vy);
          if (e.x < canvas.width * 0.45) e.vx = Math.abs(e.vx) * 0.5;
          if (time - e.lastAttackTime > 2200) {
            const dirX = s.player.x - e.x; const dirY = s.player.y - e.y;
            const dlen = Math.sqrt(dirX * dirX + dirY * dirY) || 1;
            s.projectiles.push({ x: e.x, y: e.y + e.height / 2, vx: (dirX / dlen) * 320, vy: (dirY / dlen) * 320, radius: 7, damage: 12, isEnemy: true, color: '#ff2244', trail: [] });
            e.lastAttackTime = time;
          }
        } else if (e.type === 'yellow') {
          e.zigzagPhase += dt * 2.8; e.boostCooldown -= dt;
          let speed = e.baseSpeed;
          if (e.boostTimer > 0) { e.boostTimer -= dt; speed *= 2.5; }
          else if (e.boostCooldown <= 0) { e.boostTimer = 0.4; e.boostCooldown = 3 + Math.random() * 3; }
          e.x += Math.sin(e.auraPhase * 0.4) * speed * 0.3 * dt;
          e.y += Math.sin(e.zigzagPhase) * speed * dt;
          if (e.y < 30) e.zigzagPhase = 0;
          if (e.y > canvas.height - e.height - 30) e.zigzagPhase = Math.PI;
          if (e.x < canvas.width * 0.55) e.x = canvas.width * 0.55;
          if (e.x > canvas.width - e.width - 10) e.x = canvas.width - e.width - 10;
          if (time - e.lastAttackTime > 3500) {
            const dirX = s.player.x - e.x; const dirY = s.player.y - e.y;
            const dlen = Math.sqrt(dirX * dirX + dirY * dirY) || 1;
            s.projectiles.push({ x: e.x, y: e.y + e.height / 2, vx: (dirX / dlen) * 380, vy: (dirY / dlen) * 380, radius: 14, damage: 22, isEnemy: true, color: '#ffcc00', trail: [] });
            e.lastAttackTime = time;
          }
        }
      } else if (e.state === 'retreating') {
        e.x += e.vx * dt;
        if (e.x > canvas.width + 200) s.enemies.splice(i, 1);
      }
    }

    // Particles
    for (let i = s.particles.length - 1; i >= 0; i--) {
      const p = s.particles[i];
      p.x += p.vx * dt; p.y += p.vy * dt;
      p.vx *= 0.94; p.vy = p.vy * 0.94 + (p.gravity || 0) * dt;
      if (p.rotation !== undefined && p.rotSpeed !== undefined) p.rotation += p.rotSpeed * dt;
      p.life -= dt;
      if (p.life <= 0) s.particles.splice(i, 1);
    }

    // Mission cleared
    if (s.missionState === 'active' && allCleared && s.enemies.filter(e => e.state !== 'retreating' && e.state !== 'dead').length === 0) {
      if (!missionClearPlayed.current) { playMissionClear(); missionClearPlayed.current = true; }
      s.missionState = 'cleared'; s.missionTimer = time;
    }

    if (s.missionState === 'cleared' && time - s.missionTimer > WAVE_DELAY) {
      const oldBackgroundIndex = getBackgroundIndex(s.mission);
      s.mission++; s.speedScale = Math.floor((s.mission - 1) / 3);
      const nextBackgroundIndex = getBackgroundIndex(s.mission);
      if (nextBackgroundIndex !== oldBackgroundIndex) {
        s.previousBackgroundIndex = oldBackgroundIndex;
        s.backgroundIndex = nextBackgroundIndex;
        s.backgroundTransition = 1.8;
      }
      const cfg = getMissionConfig(s.mission);
      s.player.maxHp += 15; s.player.hp = Math.min(s.player.maxHp, s.player.hp + 25);
      s.player.damage += 3; s.player.bullets = cfg.startBullets;
      const nextWeaponIdx = Math.min(Math.floor(s.mission / 3), WEAPON_ORDER.length - 1);
      const nextWeapon = WEAPON_ORDER[nextWeaponIdx];
      if (!s.unlockedWeapons.has(nextWeapon)) { s.unlockedWeapons.add(nextWeapon); s.currentWeapon = nextWeapon; showNotification(`NEW WEAPON: ${WEAPONS[nextWeapon].name} unlocked!`); }
      if (cfg.isBoss) { s.player.bullets += 200; showNotification('BOSS CLEARED! +200 Bullets!'); }
      s.spawnQueue = buildSpawnQueue(s.mission); s.spawnTimer = 0; s.missionState = 'active';
      missionClearPlayed.current = false;
      syncHud();
    }
  };

  // ── Draw ──────────────────────────────────────────────────────────────────
  const draw = (ctx: CanvasRenderingContext2D, canvas: HTMLCanvasElement) => {
    const s = state.current;
    const w = canvas.width; const h = canvas.height;
    ctx.save();
    ctx.clearRect(0, 0, w, h);
    if (s.screenShake > 0) ctx.translate((Math.random() - 0.5) * s.screenShake * 2, (Math.random() - 0.5) * s.screenShake * 2);

    // ── Cinematic sky background (new scene after every 2 missions) ──
    const drawBackground = (index: number, opacity: number) => {
      const image = s.bgImages[index];
      if (!image || opacity <= 0) return;
      const scale = Math.max(w / image.width, h / image.height) * 1.12;
      const dw = image.width * scale;
      const dh = image.height * scale;
      const maxPanX = Math.max(0, dw - w);
      const maxPanY = Math.max(0, dh - h);
      // Slow camera drift gives the impression that the aircraft is travelling through the sky.
      const panX = maxPanX * (0.5 + 0.5 * Math.sin(s.bgOffset * 0.004 + index * 0.8));
      const panY = maxPanY * (0.5 + 0.5 * Math.sin(s.bgOffset * 0.0025 + index * 1.1));
      ctx.save();
      ctx.globalAlpha = opacity;
      ctx.drawImage(image, (w - dw) / 2 - panX, (h - dh) / 2 - panY, dw, dh);
      ctx.fillStyle = 'rgba(0, 12, 34, 0.30)';
      ctx.fillRect(0, 0, w, h);
      ctx.restore();
    };

    const backgroundProgress = s.backgroundTransition > 0 ? 1 - s.backgroundTransition / 1.8 : 1;
    if (s.bgImages[s.backgroundIndex]) {
      if (s.backgroundTransition > 0 && s.previousBackgroundIndex !== s.backgroundIndex) {
        drawBackground(s.previousBackgroundIndex, 1 - backgroundProgress);
        drawBackground(s.backgroundIndex, backgroundProgress);
      } else {
        drawBackground(s.backgroundIndex, 1);
      }
    } else {
      const skyGrad = ctx.createLinearGradient(0, 0, 0, h);
      skyGrad.addColorStop(0, '#0d1b3e'); skyGrad.addColorStop(0.5, '#1a3060'); skyGrad.addColorStop(1, '#0a1020');
      ctx.fillStyle = skyGrad; ctx.fillRect(0, 0, w, h);
    }

    // Clouds (light, no shadowBlur)
    drawClouds(ctx, s.clouds);

    const t = performance.now() / 1000;
    const pl = s.player;
    const plCx = pl.x + pl.width / 2; const plCy = pl.y + pl.height / 2;

    // ── Engine flames (simplified — no shadowBlur) ──
    for (let fi = 0; fi < 3; fi++) {
      const oy = (fi - 1) * (pl.height * 0.22);
      const fx = plCx - pl.width * 0.66; const fy = plCy + oy;
      const fLen = 28 + Math.sin(t * 18 + fi * 2.1) * 14;
      const fW = 9 + Math.sin(t * 22 + fi * 1.7) * 3;
      // Outer flame — gradient only, no shadow
      const gradO = ctx.createRadialGradient(fx, fy, 0, fx - fLen * 0.5, fy, fLen);
      gradO.addColorStop(0, 'rgba(255,255,180,1)'); gradO.addColorStop(0.35, 'rgba(255,120,0,0.85)'); gradO.addColorStop(0.75, 'rgba(255,40,0,0.4)'); gradO.addColorStop(1, 'rgba(200,0,0,0)');
      ctx.save();
      ctx.beginPath(); ctx.ellipse(fx - fLen / 2, fy, fLen / 2, fW / 2, Math.PI, 0, Math.PI * 2);
      ctx.fillStyle = gradO; ctx.fill(); ctx.restore();
      // Inner hot core (opaque, no shadow)
      ctx.save();
      ctx.beginPath(); ctx.ellipse(fx - 7, fy, 9, fW * 0.28, Math.PI, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(255,255,200,0.92)'; ctx.fill(); ctx.restore();
    }
    // Smoke wisps (2 only, cheap)
    for (let si = 0; si < 2; si++) {
      ctx.save(); ctx.globalAlpha = 0.06 + Math.sin(t * 5 + si) * 0.03;
      ctx.fillStyle = '#bbbbbb';
      ctx.beginPath(); ctx.arc(pl.x - 18 - si * 16, plCy + (si - 0.5) * 10, 7 + si * 3, 0, Math.PI * 2); ctx.fill(); ctx.restore();
    }

    // ── Shield visual (drawn BEHIND player sprite) ──
    if (s.shieldActive) {
      const shieldPulse = Math.sin(t * 8) * 4;
      const shieldR = pl.width * 0.72 + shieldPulse;
      // Outer ring
      ctx.save();
      ctx.globalAlpha = 0.85;
      ctx.beginPath(); ctx.arc(plCx, plCy, shieldR + 6, 0, Math.PI * 2);
      ctx.strokeStyle = '#00eeff'; ctx.lineWidth = 3.5; ctx.stroke();
      // Inner glow fill
      ctx.beginPath(); ctx.arc(plCx, plCy, shieldR, 0, Math.PI * 2);
      ctx.fillStyle = 'rgba(0,200,255,0.12)'; ctx.fill();
      // Rotating hex segments
      for (let si = 0; si < 6; si++) {
        const sa = (si / 6) * Math.PI * 2 + t * 1.4;
        const sx1 = plCx + Math.cos(sa) * (shieldR - 3);
        const sy1 = plCy + Math.sin(sa) * (shieldR - 3);
        const sx2 = plCx + Math.cos(sa + Math.PI / 6) * (shieldR + 5);
        const sy2 = plCy + Math.sin(sa + Math.PI / 6) * (shieldR + 5);
        ctx.beginPath(); ctx.moveTo(sx1, sy1); ctx.lineTo(sx2, sy2);
        ctx.strokeStyle = `rgba(100,255,255,${0.4 + Math.sin(t * 5 + si) * 0.3})`; ctx.lineWidth = 2; ctx.stroke();
      }
      // Countdown arc — drains clockwise over 7s
      const fraction = s.shieldTimer / 7;
      ctx.beginPath();
      ctx.arc(plCx, plCy, shieldR + 10, -Math.PI / 2, -Math.PI / 2 + fraction * Math.PI * 2);
      ctx.strokeStyle = '#ffffff'; ctx.lineWidth = 2.5; ctx.globalAlpha = 0.7; ctx.stroke();
      ctx.restore();
    }

    // Player sprite: preserve the fighter jet's wide proportions and bank gently with movement.
    if (pl.hitFlashTime > 0) { ctx.save(); ctx.globalCompositeOperation = 'lighter'; ctx.fillStyle = 'rgba(255,60,60,0.5)'; ctx.fillRect(pl.x, pl.y, pl.width, pl.height); ctx.restore(); }
    if (s.images.player && s.imagesLoaded) {
      const planeImage = s.images.player;
      const spriteWidth = pl.width * 1.62;
      const spriteHeight = spriteWidth * (planeImage.height / planeImage.width);
      ctx.save();
      ctx.translate(plCx, plCy);
      const bank = (s.joystick.active ? s.joystick.dy : 0) * 0.10;
      ctx.rotate(bank);
      ctx.drawImage(planeImage, -spriteWidth / 2, -spriteHeight / 2, spriteWidth, spriteHeight);
      ctx.restore();
    } else { ctx.fillStyle = '#ff8800'; ctx.fillRect(pl.x, pl.y, pl.width, pl.height); }
    // Damage aura (no shadowBlur — just stroke)
    if (s.damageBoostedTime > 0) {
      ctx.save(); const pulse = Math.sin(t * 6) * 5;
      ctx.beginPath(); ctx.arc(plCx, plCy, pl.width / 2 + 14 + pulse, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,100,255,0.85)'; ctx.lineWidth = 3; ctx.stroke(); ctx.restore();
    }

    // ── Enemies ──
    for (const e of s.enemies) {
      if (e.state === 'dead') continue;
      const img = e.type === 'red' ? s.images.redBird : e.type === 'yellow' ? s.images.yellowBird : s.images.blueBird;
      const eCx = e.x + e.width / 2; const eCy = e.y + e.height / 2;

      // Speed trails — NO ctx.filter (it was the #1 GPU killer)
      if (e.type === 'red' || e.type === 'yellow') {
        const tc = e.type === 'yellow' ? 4 : 3;
        for (let ti = 1; ti < tc; ti++) {
          const tx = e.x - (e.vx > 0 ? ti * 12 : -ti * 12);
          ctx.save(); ctx.globalAlpha = (1 - ti / tc) * 0.18;
          if (img && s.imagesLoaded) ctx.drawImage(img, tx, e.y, e.width, e.height);
          else { ctx.fillStyle = e.type === 'red' ? '#ff3300' : '#ffcc00'; ctx.fillRect(tx, e.y, e.width, e.height); }
          ctx.restore();
        }
      }
      // Blue bird speed trail too
      if (e.type === 'blue' && (Math.abs(e.vx) > 30 || Math.abs(e.vy) > 30)) {
        ctx.save(); ctx.globalAlpha = 0.15;
        if (img && s.imagesLoaded) ctx.drawImage(img, e.x - e.vx * 0.08, e.y - e.vy * 0.08, e.width, e.height);
        ctx.restore();
      }

      // Yellow aura — gradient only, no shadowBlur
      if (e.type === 'yellow') {
        ctx.save();
        const ap = e.width / 2 + 20 + Math.sin(e.auraPhase) * 10;
        const ag = ctx.createRadialGradient(eCx, eCy, e.width * 0.3, eCx, eCy, ap);
        ag.addColorStop(0, 'rgba(255,220,0,0.35)'); ag.addColorStop(0.6, 'rgba(255,140,0,0.15)'); ag.addColorStop(1, 'rgba(255,80,0,0)');
        ctx.beginPath(); ctx.arc(eCx, eCy, ap, 0, Math.PI * 2);
        ctx.fillStyle = ag; ctx.fill(); ctx.restore();
        // Lightning bolts — no shadowBlur
        for (let bi = 0; bi < 3; bi++) {
          const ba = (bi / 3) * Math.PI * 2 + e.auraPhase * 0.7;
          const br = e.width / 2 + 8;
          const bx1 = eCx + Math.cos(ba) * br; const by1 = eCy + Math.sin(ba) * br;
          const bx2 = eCx + Math.cos(ba + 0.45) * (br + 16 + Math.sin(t * 12 + bi) * 7);
          const by2 = eCy + Math.sin(ba + 0.45) * (br + 16 + Math.sin(t * 12 + bi) * 7);
          ctx.save(); ctx.beginPath();
          ctx.moveTo(bx1, by1);
          ctx.lineTo((bx1 + bx2) / 2 + (Math.random() - 0.5) * 8, (by1 + by2) / 2 + (Math.random() - 0.5) * 8);
          ctx.lineTo(bx2, by2);
          ctx.strokeStyle = Math.random() > 0.5 ? '#ffffffcc' : '#ffee44cc'; ctx.lineWidth = 1.5;
          ctx.globalAlpha = 0.65 + Math.random() * 0.35; ctx.stroke(); ctx.restore();
        }
      }

      // Wing flap
      const flapSpeed = e.type === 'blue' ? 4.5 : e.type === 'red' ? 6.5 : 3.5;
      const flapAmt = e.type === 'yellow' ? 0.08 : 0.13;
      const wingScaleY = 1 + Math.sin(e.auraPhase * flapSpeed) * flapAmt;
      ctx.save(); ctx.translate(eCx, eCy); ctx.scale(1, wingScaleY); ctx.translate(-eCx, -eCy);
      if (img && s.imagesLoaded) ctx.drawImage(img, e.x, e.y, e.width, e.height);
      else { ctx.fillStyle = e.type === 'blue' ? '#3399ff' : e.type === 'red' ? '#ff3333' : '#ffcc00'; ctx.fillRect(e.x, e.y, e.width, e.height); }
      ctx.restore();

      // Blue beak attack visual (no shadowBlur)
      if (e.type === 'blue' && e.state === 'attacking') {
        const px = pl.x + pl.width / 2; const py = pl.y + pl.height / 2;
        const dist = Math.sqrt((px - eCx) ** 2 + (py - eCy) ** 2);
        if (dist < 180) {
          const angle = Math.atan2(py - eCy, px - eCx);
          const beakLen = 20 + Math.sin(t * 14) * 7;
          const bTipX = eCx + Math.cos(angle) * (e.width / 2 + beakLen);
          const bTipY = eCy + Math.sin(angle) * (e.height / 2 + beakLen);
          ctx.save(); ctx.beginPath();
          ctx.moveTo(eCx + Math.cos(angle + Math.PI / 2) * 7, eCy + Math.sin(angle + Math.PI / 2) * 7);
          ctx.lineTo(bTipX, bTipY);
          ctx.lineTo(eCx + Math.cos(angle - Math.PI / 2) * 7, eCy + Math.sin(angle - Math.PI / 2) * 7);
          ctx.closePath();
          ctx.fillStyle = '#ffdd44'; ctx.fill();
          ctx.strokeStyle = '#ff8800'; ctx.lineWidth = 1.5; ctx.stroke(); ctx.restore();
        }
      }

      // Red glow — simple fill, no shadowBlur
      if (e.type === 'red') {
        ctx.save(); ctx.beginPath(); ctx.arc(eCx, eCy, e.width * 0.28, 0, Math.PI * 2);
        ctx.fillStyle = `rgba(255,40,60,${0.1 + Math.sin(t * 8) * 0.05})`; ctx.fill(); ctx.restore();
      }

      // HP bars (no shadowBlur)
      if (e.type !== 'blue' || e.hp < e.maxHp) {
        const bw = e.width;
        ctx.fillStyle = 'rgba(0,0,0,0.6)'; ctx.fillRect(e.x, e.y - 14, bw, 8);
        const hpPct = Math.max(0, e.hp / e.maxHp);
        ctx.fillStyle = e.type === 'yellow' ? '#ffcc00' : e.type === 'red' ? '#ff4444' : '#44aaff';
        ctx.fillRect(e.x, e.y - 14, bw * hpPct, 8);
        ctx.strokeStyle = 'rgba(255,255,255,0.2)'; ctx.lineWidth = 1; ctx.strokeRect(e.x, e.y - 14, bw, 8);
      }
    }

    // ── Projectiles (no shadowBlur — bright color + white ring instead) ──
    for (const p of s.projectiles) {
      // Trail line
      if (p.trail && p.trail.length > 1) {
        ctx.save(); ctx.beginPath(); ctx.moveTo(p.trail[0].x, p.trail[0].y);
        for (let i = 1; i < p.trail.length; i++) ctx.lineTo(p.trail[i].x, p.trail[i].y);
        ctx.lineTo(p.x, p.y);
        ctx.strokeStyle = (p.color || '#ffffaa') + '44'; ctx.lineWidth = p.radius * 1.6; ctx.lineCap = 'round'; ctx.stroke(); ctx.restore();
      }
      // Bullet body — solid bright circle + thin white ring (no shadow)
      ctx.save();
      ctx.beginPath(); ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = p.color || '#ffffaa'; ctx.fill();
      ctx.beginPath(); ctx.arc(p.x, p.y, p.radius + 1.5, 0, Math.PI * 2);
      ctx.strokeStyle = 'rgba(255,255,255,0.45)'; ctx.lineWidth = 1; ctx.stroke();
      ctx.restore();
    }

    // ── Particles (NO shadowBlur at all — biggest perf win) ──
    for (const p of s.particles) {
      const alpha = Math.max(0, p.life / p.maxLife);
      ctx.save(); ctx.globalAlpha = alpha;
      if (p.type === 'floatText') {
        ctx.font = `bold ${p.size}px "Inter", sans-serif`;
        ctx.fillStyle = p.color;
        ctx.textAlign = 'center'; ctx.fillText(p.text || '', p.x, p.y);
      } else if (p.type === 'feather') {
        ctx.translate(p.x, p.y); ctx.rotate(p.rotation || 0);
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.ellipse(0, 0, p.size * 0.35, p.size, 0, 0, Math.PI * 2); ctx.fill();
      } else if (p.type === 'smoke') {
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size * (1 + (1 - alpha) * 0.7), 0, Math.PI * 2); ctx.fill();
      } else {
        // spark — bright fill, no shadow
        ctx.fillStyle = p.color;
        ctx.beginPath(); ctx.arc(p.x, p.y, p.size, 0, Math.PI * 2); ctx.fill();
      }
      ctx.restore();
    }

    // ── Mission cleared banner ──
    if (s.missionState === 'cleared') {
      ctx.save();
      const bh = h * 0.18;
      ctx.fillStyle = 'rgba(0,0,0,0.55)'; ctx.fillRect(0, h / 2 - bh / 2 - 10, w, bh);
      ctx.textAlign = 'center';
      ctx.font = `bold ${Math.round(w * 0.058)}px "Inter", sans-serif`;
      ctx.shadowColor = '#ff8800'; ctx.shadowBlur = 20;
      ctx.fillStyle = '#ffcc00'; ctx.fillText(`MISSION ${s.mission} CLEARED!`, w / 2, h / 2 - 15);
      ctx.font = `bold ${Math.round(w * 0.032)}px "Inter", sans-serif`;
      ctx.fillStyle = '#ffffff'; ctx.shadowBlur = 8;
      ctx.fillText('Next mission incoming...', w / 2, h / 2 + 28); ctx.restore();
    }

    // ── Combo display ──
    if (s.combo >= 3) {
      ctx.save(); ctx.textAlign = 'center';
      ctx.globalAlpha = Math.min(1, s.comboTimer);
      const sz = Math.min(s.combo * 3, 58);
      ctx.font = `bold ${sz}px "Inter", sans-serif`;
      ctx.fillStyle = s.combo >= 10 ? '#ff44ff' : '#ffcc00';
      ctx.shadowColor = ctx.fillStyle; ctx.shadowBlur = 18;
      ctx.fillText(`${s.combo}x COMBO!`, w / 2, h * 0.73); ctx.restore();
    }

    ctx.restore();
  };

  // ── Game Loop ─────────────────────────────────────────────────────────────
  const gameLoop = useCallback((time: number) => {
    const s = state.current;
    if (!s.lastTime) s.lastTime = time;
    const dt = Math.min((time - s.lastTime) / 1000, 0.05);
    s.lastTime = time;
    if (gamePhaseRef.current === 'playing') {
      update(dt, time);
      const canvas = canvasRef.current;
      const ctx = ctxRef.current;
      if (canvas && ctx) draw(ctx, canvas);
    }
    requestRef.current = requestAnimationFrame(gameLoop);
  }, []);

  useEffect(() => {
    gamePhaseRef.current = gamePhase;
    if (gamePhase === 'playing') {
      const canvas = canvasRef.current;
      if (canvas) {
        canvas.width = window.innerWidth;
        canvas.height = window.innerHeight;
        ctxRef.current = canvas.getContext('2d');
      }
      const s = state.current;
      s.isGameOver = false;
      s.player = { x: 100, y: window.innerHeight / 2, width: 70, height: 70, hp: 100, maxHp: 100, damage: 10, bullets: 50, hitFlashTime: 0 };
      s.enemies = []; s.projectiles = []; s.particles = [];
      s.clouds = makeClouds(window.innerWidth, window.innerHeight);
      s.mission = 1; s.score = 0; s.missionState = 'active'; s.lastTime = 0;
      s.combo = 0; s.comboTimer = 0; s.damageBoostedTime = 0;
      s.shieldCharges = 0; s.shieldActive = false; s.shieldTimer = 0;
      s.currentWeapon = 'pistol'; s.unlockedWeapons = new Set(['pistol']);
      s.notification = ''; s.notificationTimer = 0; s.screenShake = 0; s.bgOffset = 0; s.speedScale = 0;
      s.backgroundIndex = 0; s.previousBackgroundIndex = 0; s.backgroundTransition = 0;
      s.spawnQueue = buildSpawnQueue(1); s.spawnTimer = 0.5; s.spawnInterval = 1.5; s.lastShotTime = 0;
      missionClearPlayed.current = false;
      syncHud();
      // Respect the Home screen music toggle. Audio starts only after a user tap.
      if (musicEnabledRef.current) startBGMusic(); else stopBGMusic();
    }
    if (gamePhase === 'gameover') stopBGMusic();
    requestRef.current = requestAnimationFrame(gameLoop);
    return () => {
      if (requestRef.current) cancelAnimationFrame(requestRef.current);
      if (gamePhase !== 'playing') stopBGMusic();
    };
  }, [gamePhase, gameLoop]);

  useEffect(() => {
    const onResize = () => {
      if (canvasRef.current) {
        canvasRef.current.width = window.innerWidth;
        canvasRef.current.height = window.innerHeight;
        ctxRef.current = canvasRef.current.getContext('2d');
      }
    };
    window.addEventListener('resize', onResize);
    return () => window.removeEventListener('resize', onResize);
  }, []);

  // ── Joystick ──────────────────────────────────────────────────────────────
  const handleJoystickStart = (e: React.TouchEvent | React.MouseEvent) => { state.current.joystick.active = true; updateJoystick(e); };
  const handleJoystickMove = (e: React.TouchEvent | React.MouseEvent) => { if (state.current.joystick.active) updateJoystick(e); };
  const handleJoystickEnd = () => {
    const s = state.current; s.joystick.active = false; s.joystick.dx = 0; s.joystick.dy = 0;
    if (joystickStickRef.current) joystickStickRef.current.style.transform = 'translate(0px, 0px)';
  };
  const updateJoystick = (e: React.TouchEvent | React.MouseEvent) => {
    if (!joystickBaseRef.current || !joystickStickRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const cx = rect.left + rect.width / 2; const cy = rect.top + rect.height / 2;
    let clientX: number, clientY: number;
    if ('touches' in e) { clientX = e.touches[0].clientX; clientY = e.touches[0].clientY; }
    else { clientX = (e as React.MouseEvent).clientX; clientY = (e as React.MouseEvent).clientY; }
    let dx = clientX - cx; let dy = clientY - cy;
    const dist = Math.sqrt(dx * dx + dy * dy); const maxR = rect.width / 2;
    if (dist > maxR) { dx = (dx / dist) * maxR; dy = (dy / dist) * maxR; }
    joystickStickRef.current.style.transform = `translate(${dx}px, ${dy}px)`;
    state.current.joystick.dx = dx / maxR; state.current.joystick.dy = dy / maxR;
  };

  // ── HP color helper ───────────────────────────────────────────────────────
  const hpPct = hudData.maxHp > 0 ? hudData.hp / hudData.maxHp : 0;
  const hpColor = hpPct > 0.6 ? 'from-green-600 to-green-400' : hpPct > 0.3 ? 'from-yellow-600 to-yellow-400' : 'from-red-700 to-red-400';

  return (
    <div className="relative w-full h-[100dvh] overflow-hidden bg-[#0a0a1a] select-none">
      <canvas ref={canvasRef} className="block w-full h-full" />

      {/* HUD */}
      {gamePhase === 'playing' && (
        <>
          {/* HP Bar — top left */}
          <div className="absolute top-3 left-3 w-48 z-10">
            <div className="flex items-center justify-between mb-1">
              <span className="text-white text-xs font-bold drop-shadow">❤️ HP</span>
              <span className="text-white text-xs font-bold drop-shadow">{hudData.hp}/{hudData.maxHp}</span>
            </div>
            <div className="h-4 w-full bg-black/60 border border-white/25 rounded-full overflow-hidden shadow-inner">
              <div className={`h-full bg-gradient-to-r ${hpColor} transition-all duration-200 rounded-full`}
                style={{ width: `${Math.max(0, hpPct * 100)}%` }} />
            </div>
          </div>

          {/* Mission + Score — top center */}
          <div className="absolute top-2 left-1/2 -translate-x-1/2 text-center z-10 pointer-events-none">
            <div className="bg-black/50 border border-primary/40 rounded-xl px-4 py-1.5 shadow-[0_0_12px_rgba(255,165,0,0.4)]">
              <div className="text-primary font-black text-base tracking-widest drop-shadow-[0_0_8px_rgba(255,165,0,0.9)]">
                MISSION {hudData.mission}
              </div>
              <div className="text-white/80 text-xs font-bold">⭐ {hudData.score.toLocaleString()}</div>
            </div>
          </div>

          {/* Bullets + Weapon — top right */}
          <div className="absolute top-3 right-3 z-10 text-right">
            <div className={`text-lg font-black drop-shadow ${hudData.bullets < 10 ? 'text-red-400 animate-pulse' : 'text-yellow-300'}`}>
              🔫 {hudData.bullets}
            </div>
            <div className={`text-xs font-bold mt-0.5 ${hudData.damageBoosted ? 'text-pink-400 animate-pulse' : 'text-white/70'}`}>
              {WEAPONS[hudData.weapon].name}{hudData.damageBoosted ? ' ⚡x2' : ''}
            </div>
          </div>

          {/* Notification */}
          {hudData.weaponUnlocked && (
            <div className="absolute top-16 left-1/2 -translate-x-1/2 z-20 pointer-events-none">
              <div className="bg-black/75 border border-yellow-400/60 rounded-xl px-5 py-2 text-yellow-300 font-bold text-sm animate-bounce text-center">
                {hudData.weaponUnlocked}
              </div>
            </div>
          )}

          {/* Fire button */}
          <button
            className="absolute bottom-28 right-6 w-20 h-20 rounded-full bg-red-600/80 border-2 border-red-400 text-white font-black text-lg z-10 active:scale-90 transition-transform shadow-lg"
            onTouchStart={(e) => { e.preventDefault(); fireBullet(); }}
            onMouseDown={fireBullet}
          >🔥 FIRE</button>

          {/* Weapon cycle buttons */}
          <div className="absolute bottom-52 right-6 flex flex-col gap-2 z-10">
            <button className="w-12 h-12 rounded-full bg-blue-700/70 border border-blue-400 text-white text-xs font-bold active:scale-90 transition-transform" onTouchStart={(e)=>{e.preventDefault();cycleWeapon(1);}} onMouseDown={()=>cycleWeapon(1)}>▲ WPN</button>
            <button className="w-12 h-12 rounded-full bg-blue-700/70 border border-blue-400 text-white text-xs font-bold active:scale-90 transition-transform" onTouchStart={(e)=>{e.preventDefault();cycleWeapon(-1);}} onMouseDown={()=>cycleWeapon(-1)}>▼ WPN</button>
          </div>

          {/* Joystick */}
          <div
            ref={joystickBaseRef}
            className="absolute bottom-8 left-8 w-32 h-32 rounded-full bg-white/10 border-2 border-white/25 z-10 touch-none"
            onTouchStart={handleJoystickStart} onTouchMove={handleJoystickMove} onTouchEnd={handleJoystickEnd}
            onMouseDown={handleJoystickStart} onMouseMove={handleJoystickMove} onMouseUp={handleJoystickEnd}
          >
            <div ref={joystickStickRef} className="absolute inset-0 m-auto w-14 h-14 rounded-full bg-white/30 border-2 border-white/50 pointer-events-none transition-none" />
          </div>
        </>
      )}

      {/* Home screen: only the Play and Music controls */}
      {gamePhase === 'start' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center overflow-hidden bg-[#07172e] z-20 px-6">
          <div className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_25%,rgba(54,126,193,0.44),transparent_55%),linear-gradient(180deg,#09264a_0%,#11162c_58%,#080d1b_100%)]" />
          <div className="absolute -left-16 top-16 h-56 w-56 rounded-full bg-sky-400/10 blur-3xl" />
          <div className="absolute -right-16 bottom-16 h-64 w-64 rounded-full bg-orange-500/10 blur-3xl" />
          <div className="relative z-10 flex w-full max-w-sm flex-col items-center text-center">
            <img
              src={`${import.meta.env.BASE_URL}app-icon.png`}
              alt="Bullet Storm Flyer fighter jet versus bird artwork"
              className="mb-5 h-52 w-52 rounded-[2rem] border border-sky-200/50 object-cover shadow-[0_18px_50px_rgba(0,0,0,0.55),0_0_32px_rgba(56,189,248,0.22)] sm:h-60 sm:w-60"
              draggable={false}
            />
            <h1 className="text-4xl font-black tracking-wider text-white drop-shadow-[0_3px_12px_rgba(0,0,0,0.8)] sm:text-5xl">
              BULLET STORM
            </h1>
            <h2 className="mb-8 text-3xl font-black tracking-[0.28em] text-amber-400 drop-shadow-[0_0_16px_rgba(251,146,60,0.55)]">
              FLYER
            </h2>
            <div className="flex w-full flex-col gap-4">
              <Button
                className="w-full rounded-2xl border border-amber-200 bg-gradient-to-r from-amber-500 via-orange-500 to-red-600 py-6 text-xl font-black tracking-wider text-white shadow-[0_0_30px_rgba(249,115,22,0.45)] hover:brightness-110"
                onClick={() => setGamePhase('playing')}
              >
                ▶ PLAY
              </Button>
              <Button
                variant="outline"
                className="w-full rounded-2xl border border-sky-300/80 bg-sky-950/70 py-6 text-lg font-bold tracking-wider text-sky-100 shadow-[0_0_22px_rgba(56,189,248,0.22)] hover:bg-sky-900/80"
                onClick={toggleMusic}
                aria-pressed={musicEnabled}
              >
                ♫ MUSIC {musicEnabled ? 'ON' : 'OFF'}
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Game Over */}
      {gamePhase === 'gameover' && (
        <div className="absolute inset-0 flex flex-col items-center justify-center bg-black/75 z-20">
          <div className="text-center px-6">
            <h1 className="text-5xl font-black text-red-500 drop-shadow-[0_0_20px_rgba(255,0,0,0.8)] mb-4">GAME OVER</h1>
            <p className="text-white/70 text-lg mb-2">Final Score</p>
            <p className="text-yellow-400 text-4xl font-black mb-8">{hudData.score.toLocaleString()}</p>
            <Button
              className="text-xl px-10 py-5 bg-gradient-to-r from-orange-500 to-red-600 hover:from-orange-400 hover:to-red-500 text-white font-black rounded-2xl shadow-[0_0_30px_rgba(255,100,0,0.6)] border border-orange-300"
              onClick={() => { stopBGMusic(); setGamePhase('playing'); }}
            >
              🔄 PLAY AGAIN
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
