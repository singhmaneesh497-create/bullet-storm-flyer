import type { CapacitorConfig } from '@capacitor/cli';

const config: CapacitorConfig = {
  appId: 'com.bulletstorm.flyer',
  appName: 'Bullet Storm Flyer',
  webDir: 'dist/public',
  bundledWebRuntime: false,
  android: {
    allowMixedContent: false,
  },
};

export default config;
