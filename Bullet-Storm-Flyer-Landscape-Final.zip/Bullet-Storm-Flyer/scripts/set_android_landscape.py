#!/usr/bin/env python3
"""Set the generated Capacitor Android activity to landscape orientation."""
from pathlib import Path
import re
import sys

manifest = Path(sys.argv[1]) if len(sys.argv) > 1 else Path(
    "artifacts/angry-birds-shooter/android/app/src/main/AndroidManifest.xml"
)
if not manifest.is_file():
    raise SystemExit(f"Android manifest not found: {manifest}")
text = manifest.read_text(encoding="utf-8")
pattern = re.compile(r'(<activity\b(?=[^>]*android:name="\.MainActivity")[^>]*)(/?>)', re.DOTALL)
match = pattern.search(text)
if not match:
    raise SystemExit("Could not find Capacitor .MainActivity in AndroidManifest.xml")
tag = match.group(1)
if re.search(r'android:screenOrientation="[^"]+"', tag):
    tag = re.sub(r'android:screenOrientation="[^"]+"', 'android:screenOrientation="landscape"', tag)
else:
    tag += ' android:screenOrientation="landscape"'
text = text[:match.start(1)] + tag + match.group(2) + text[match.end(2):]
manifest.write_text(text, encoding="utf-8")
if 'android:screenOrientation="landscape"' not in text:
    raise SystemExit("Landscape orientation verification failed")
print(f"Locked Android activity to landscape: {manifest}")
