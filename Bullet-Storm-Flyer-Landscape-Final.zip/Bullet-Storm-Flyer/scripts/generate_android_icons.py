#!/usr/bin/env python3
"""Generate Android launcher icon resources from the project's app-icon.png."""
from __future__ import annotations

import argparse
from pathlib import Path
from PIL import Image, ImageOps


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--icon", required=True, help="Path to square source PNG")
    parser.add_argument("--res", required=True, help="Android app/src/main/res directory")
    args = parser.parse_args()

    icon_path = Path(args.icon)
    res = Path(args.res)
    if not icon_path.is_file():
        raise SystemExit(f"Icon not found: {icon_path}")

    image = Image.open(icon_path).convert("RGBA")
    image = ImageOps.fit(image, (1024, 1024), method=Image.Resampling.LANCZOS)

    # Legacy launcher icons for older Android versions.
    densities = {"mdpi": 48, "hdpi": 72, "xhdpi": 96, "xxhdpi": 144, "xxxhdpi": 192}
    for density, size in densities.items():
        folder = res / f"mipmap-{density}"
        folder.mkdir(parents=True, exist_ok=True)
        rendered = image.resize((size, size), Image.Resampling.LANCZOS)
        rendered.save(folder / "ic_launcher.png", optimize=True)
        rendered.save(folder / "ic_launcher_round.png", optimize=True)

    # Android adaptive icon: keep the artwork inside the central safe area.
    foreground_folder = res / "drawable-nodpi"
    foreground_folder.mkdir(parents=True, exist_ok=True)
    foreground = Image.new("RGBA", (432, 432), (0, 0, 0, 0))
    safe_art = image.resize((324, 324), Image.Resampling.LANCZOS)
    foreground.alpha_composite(safe_art, ((432 - 324) // 2, (432 - 324) // 2))
    foreground.save(foreground_folder / "ic_launcher_foreground.png", optimize=True)

    drawable = res / "drawable"
    drawable.mkdir(parents=True, exist_ok=True)
    (drawable / "ic_launcher_background.xml").write_text(
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<shape xmlns:android="http://schemas.android.com/apk/res/android" android:shape="rectangle">\n'
        '    <solid android:color="#0B2342" />\n'
        '</shape>\n',
        encoding="utf-8",
    )

    adaptive = res / "mipmap-anydpi-v26"
    adaptive.mkdir(parents=True, exist_ok=True)
    adaptive_xml = (
        '<?xml version="1.0" encoding="utf-8"?>\n'
        '<adaptive-icon xmlns:android="http://schemas.android.com/apk/res/android">\n'
        '    <background android:drawable="@drawable/ic_launcher_background" />\n'
        '    <foreground android:drawable="@drawable/ic_launcher_foreground" />\n'
        '</adaptive-icon>\n'
    )
    (adaptive / "ic_launcher.xml").write_text(adaptive_xml, encoding="utf-8")
    (adaptive / "ic_launcher_round.xml").write_text(adaptive_xml, encoding="utf-8")
    print(f"Android launcher icons generated from {icon_path}")


if __name__ == "__main__":
    main()
